/*
Navicat MySQL Data Transfer

Source Server         : sf
Source Server Version : 50528
Source Host           : 127.0.0.1:3306
Source Database       : webchat

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2018-08-30 16:16:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for log
-- ----------------------------

DROP DATABASE IF EXISTS `webchat`;
CREATE DATABASE webchat;
use webchat;



DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
  `id` varchar(255) DEFAULT NULL COMMENT '日志编号',
  `userid` varchar(255) DEFAULT NULL COMMENT '用户名',
  `time` varchar(255) DEFAULT NULL COMMENT '操作时间',
  `type` varchar(255) DEFAULT NULL COMMENT '操作类型',
  `detail` varchar(255) DEFAULT NULL COMMENT '详情',
  `ip` varchar(255) DEFAULT NULL COMMENT 'ip',
  KEY `fk_log_userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of log
-- ----------------------------
INSERT INTO `log` VALUES ('a9786c018d854226bdfa0ab74d4045cf', 'Amayadream', '2017-01-11 19:20:43', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('9136815071cc450ba00d9b693247dff2', 'Amayadream', '2017-01-11 19:21:26', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('2be39dd8511c41259bfa2885353e94ad', 'Amayadream', '2017-01-11 19:21:52', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('a48f35f8d3f84db1addc42cbf8835ac8', 'Amayadream', '2017-01-11 19:22:15', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('48083bcfca7b4dbdb7236561cc118839', 'Amayadream', '2017-01-11 19:22:18', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('2c83a3d453d94f83ac7595b4bb1fc2c6', 'Amayadream', '2017-01-11 19:22:21', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('d05d2127977146dfbd0cf6076283c9e9', 'admin', '2017-01-11 19:23:20', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('19b6f5ec3d6a4a3aacbbae28ea23afd2', 'admin', '2017-01-11 19:24:04', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('f85c9989606b4b94add0b26fe5283572', 'admin', '2018-05-19 13:17:58', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('71fa471bfef04bb7b0777a39397cd415', 'admin', '2018-05-19 13:18:28', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('82c1a045bc914fdd9d3ef0ff37d630c6', 'Amayadream', '2018-05-19 13:20:10', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('402dacc7beba42f9897c452223ad5cb3', 'Amayadream', '2018-05-19 13:20:50', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('d56bee96c1b349e8afdca3f63804e411', 'admin', '2018-05-19 13:21:10', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('efbe584bea9a477c84b24cb941af55a0', 'admin', '2018-05-19 13:22:13', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('19d0e594e36c4592ba87d79baaa51104', 'admin', '2018-05-19 13:22:25', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('277c6403131642cf9d810abf35760770', 'Amayadream', '2018-05-19 13:22:53', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('a9556846d35a458b86d2ee6bd29387c4', 'sf', '2018-05-19 13:24:47', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('64636529b2d544b1a062377d0752b6fa', 'admin', '2018-05-19 13:30:44', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('3d6dc5c022cb4a3aa7eb2e604c9ff70a', 'sf', '2018-05-19 13:34:25', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('0621bcab9b0043cd926ee8e2777a4ae0', 'sf', '2018-05-19 13:34:50', '更新', '更新用户资料', null);
INSERT INTO `log` VALUES ('b4e89e40f53a4dbe9351d4c2e93e33b6', 'admin', '2018-05-19 13:51:58', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('b229048620e940cc9448abf245ccbf13', 'sf', '2018-05-19 13:53:05', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('5b0d18263d1a46d4864e5ed2bba5cb8e', 'sf', '2018-05-19 14:08:58', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('82c45966bc21495881f1dd78374cb53c', 'sf', '2018-05-19 14:09:34', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('45e696e301be4fdcad19355ef1c65922', 'sf', '2018-05-19 14:11:08', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('42bae8c0117c499da7df67d789194ef4', 'admin', '2018-05-20 09:03:19', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('418aef60454949b0b64fdda6d7833c6a', 'admin', '2018-05-20 09:03:39', '更新', '更新密码', null);
INSERT INTO `log` VALUES ('9d207143dc134f89a4e699ee6583f9f2', 'admin', '2018-05-20 09:21:39', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('e926109263d94af29a5ac309d2428ccc', 'sf', '2018-05-20 10:22:37', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('6a84f3e1946e462caec2b65d733b429d', 'sf', '2018-05-20 10:24:17', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('0971a74f848d4a86b5ad3f9583f87974', 'sf', '2018-05-20 10:25:17', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('5aa993b13c0c4d1aaf420691cfeb6fff', 'admin', '2018-05-20 10:27:11', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('717ae7dfbafc4ad1988cd1f4f2b253ed', 'sf', '2018-05-20 10:27:50', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('45914f68746f4b5bbf53a7cfe50733f3', 'Amayadream', '2018-05-20 10:30:02', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('5131f84329ea4c949c6675a350fbd660', 'sf', '2018-05-20 10:30:48', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('3c5bf67f271b4e85850063f1fdeee126', 'sf', '2018-05-20 10:35:28', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('82257d53c4574ff1a62e3302ade2979f', 'gzy', '2018-05-20 10:36:25', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('a666b8d7a58e41c595b973a114686a61', 'sf', '2018-05-20 10:38:07', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('b462c98dffdb42578c7797f43ace7639', 'sf', '2018-05-20 10:38:41', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('c5a7c478395f4b338f0afd240837ac9c', 'sf', '2018-05-20 10:39:13', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('54d16832f86a47f784c45005673935bf', 'sf', '2018-05-20 10:41:46', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('28a3dc241a314ca3b5203e846ee23f2b', 'sf', '2018-05-20 10:42:29', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('7e926e062806432caf3c4d6a062d8230', 'cq', '2018-05-20 10:53:59', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('7d77955d3c8e41a7977a675e151679e7', 'sf', '2018-05-20 16:45:32', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('4abb29f624714a6c9abb5b560b21f3a4', 'sf', '2018-05-20 16:53:40', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('ff73aa22e608478bbe8ccfcea50e9ad5', 'sf', '2018-05-20 17:20:57', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('55eff3f77aea46c297a7b32ee2c35677', 'sf', '2018-05-20 20:08:42', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('5c349079e02f4f4a9ccd018b6469d3f3', 'sf', '2018-05-20 20:28:47', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('d424d430fc6c4ddc8436ba1d44f0a695', 'sf', '2018-05-20 20:31:59', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('77150aad2302427e91574f7bec81c08f', 'sf', '2018-05-20 21:02:50', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('3425103d6d034fa6813a6664c612cc03', 'sf', '2018-05-20 21:03:19', '更新', '更新用户资料', null);
INSERT INTO `log` VALUES ('c8526132b16d4036ab9bdb0364865175', 'sf', '2018-05-20 21:06:51', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('207c0b9fb4d84fe58176c3ad40d79b05', 'sf', '2018-05-20 21:10:31', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('802a708c50be4adcb02d47c82945ef22', 'sf', '2018-05-20 21:13:28', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('2fb40cbc9d29442dbbfb3d3179253a2d', 'sf', '2018-05-20 21:15:37', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('c43af651fa97405c8ba25084157ce5b3', 'sf', '2018-05-20 21:17:52', '更新', '更新用户资料', null);
INSERT INTO `log` VALUES ('960363cb1b5d406982bded210689a023', 'sf', '2018-05-20 21:18:30', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('f9d771ef9d0e4425a56734679946a003', 'sf', '2018-05-20 21:34:55', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('096d8cb242f04f08bd677f43950057df', 'sf', '2018-05-20 21:43:48', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('da4d312d0d8e457eb55dfe6cd383a49a', 'sf', '2018-05-20 21:45:41', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('a67ee7a9770d4ab19489d494a562df2d', 'sf', '2018-05-21 15:24:02', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('a6e003d03b094a2ab43c3e36e195b1b6', 'sf', '2018-05-21 15:31:23', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('db663d1b00a24c148c638dc7fc029a8b', 'sf', '2018-05-21 15:33:40', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('e37d6b775ca44a57b5f562bd171b864f', 'sf', '2018-05-21 15:36:10', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('6510cfa5b63b494baaf1b7eac06b81ec', 'sf', '2018-05-21 15:36:25', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('d18c8cbe088c4e4d9af2e10b74417756', 'sf', '2018-05-21 15:45:16', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('e6ed2073ac8245a6a8cea989ca23a6d0', 'sf', '2018-05-21 15:45:38', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('3123deec3c924865b2180315fc8469c6', 'sf', '2018-05-21 15:48:27', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('b559aa01c65742279c70d9230e0b74d9', 'sf', '2018-05-21 15:48:34', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('1bb7ea4c93484b228a6a1be61398b9f2', 'sf', '2018-05-21 15:49:56', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('31edcfe2ac874e37aec9aa1f2d05b980', 'sf', '2018-05-21 15:53:55', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('c767a389b75542559c01e2913c65a011', 'sf', '2018-05-21 16:02:31', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('3752bdf7ff7c46bc81f36ea155f194f8', 'sf', '2018-05-21 16:04:15', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('7d7c03c580f24415a5d4411af0c7986b', 'sf', '2018-05-22 19:03:32', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('d6ac3876e66948de836f22c0a48b140d', 'sf', '2018-05-22 19:04:59', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('bccf9642606f4dcabb7d7a770384f7db', 'sf', '2018-05-22 19:05:51', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('013fcaf40dc74092a960e287a82d5d45', 'sf', '2018-05-22 19:05:59', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('1480bc5fe99c4dd2be0de93a8a3fb0e2', 'sf', '2018-05-22 19:15:38', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('097094e8a6194f23a31728f5a30e58a6', 'sf', '2018-05-22 19:48:26', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('81be9591918240e2bd38bc9b8b4510e7', 'sf', '2018-05-22 19:52:09', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('20993e70d40b49d0a7c85a442783cbd7', 'sf', '2018-05-22 19:56:20', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('596f1e5df4ad41e5bde4828cd7417c84', 'sf', '2018-05-22 19:58:47', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('765429fca6e845758d947009bcec7ecb', 'sf', '2018-05-22 20:11:44', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('cda7b02e957b4d0084d225213db9a146', 'sf', '2018-05-22 20:28:16', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('53be1093ef944716833d9e8bc408670d', 'sf', '2018-05-22 20:45:33', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('96df7722f71845c489020d1b0edb9f3a', 'sf', '2018-05-22 20:46:13', '更新', '更新用户资料', null);
INSERT INTO `log` VALUES ('fd34b795730e404daf63fe34397ec93d', 'sf', '2018-05-22 21:02:02', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('50da60a35e6d4c1a9ed2b7bf5c775ac8', 'aa', '2018-05-23 11:02:11', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('7ac7d66b6d044dfbb3569be6c7220f86', 'sf', '2018-05-23 17:16:20', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('01146f83fdea4c799b64414aa1019dda', 'sf', '2018-05-23 22:58:15', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('a7556f06142b4b539fe2bd55b715ee47', 'sf', '2018-05-23 22:58:32', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('46d439cb44344a60a22959ed85240bb5', 'sf', '2018-05-23 23:00:22', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('12f7c2c23fb948d69a13796f90d2e44b', 'sf', '2018-05-23 23:03:30', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('914f44b23a27484885e7b99f4732b7b0', 'sf', '2018-05-23 23:03:57', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('d47ee1afff144301b0f0410aadfeb2e5', 'sf', '2018-05-23 23:05:24', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('47e714a3572e4e3cb12c86a66ba932d5', 'sf', '2018-05-23 23:08:27', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('593b9a30948a4448a56d84602707e114', 'sf', '2018-05-23 23:09:08', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('cf2642a45a7844a7a52821d5cd4e7872', 'sf', '2018-05-23 23:28:03', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('def880e4541546af89789dd52d4ec20d', 'sf', '2018-05-24 00:05:42', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('08c5aa9a3f9445e9853064a80a0c6515', 'sf', '2018-05-24 00:05:54', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('5d4273c4d282433c9d82865e7039dfcc', 'sf', '2018-05-24 00:06:20', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('701851e44fa3473a8cbbc77cd1c15094', 'sf', '2018-05-24 00:07:22', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('0aa44eda20d048c5a06d6a60a49c387c', 'sf', '2018-05-24 00:07:57', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('4331aaf08f9f42d9a0e03fade6bcccdc', 'sf', '2018-05-24 00:11:37', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('eeff13dd60d448448b03e73a47d21bb0', 'sf', '2018-05-24 00:15:24', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('f46ef4aa748e41d0a7de41ee40b1c01b', 'sf', '2018-05-24 00:20:45', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('4c3d4858a02b46e78a3767eb0d002d36', 'sf', '2018-05-24 00:22:12', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('8860efb7163a42158b1a3c04619a0bfe', 'sf', '2018-05-24 00:22:40', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('fedcb9904f134dc280a5237406f5cc43', 'zz', '2018-05-25 12:41:02', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('f58140af600347e7a1915b0af753f379', 'sf', '2018-05-25 12:45:52', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('e9700f3d033840058c93c7e98a718375', 'sf', '2018-05-25 12:46:06', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('24e845a57ec247f6b3fbbd47828b7f78', 'sf', '2018-05-25 12:48:21', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('7a21f9492fbe4960b751fe4a0bf44ec8', 'sf', '2018-05-25 12:48:27', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('14b46315cbe947efb132aad35469ea86', 'sf', '2018-05-25 12:50:17', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('33cfaf40d95c4b3d9842ee218b55ed09', 'sf', '2018-05-25 12:51:27', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('696a75ff6ad34ab083e068ee880b94d2', 'sf', '2018-05-25 12:51:36', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('e0af7d5c0ee0455882ed14be1ad541ee', 'sf', '2018-05-25 17:33:32', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('d83cb8b7882a40e98e288945af74855c', 'sf', '2018-05-25 17:33:41', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('6fb6bef74e5a4ca2b684a644d659f42e', 'sf', '2018-05-25 17:34:55', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('4eeb7987542f46cba6171831b6bd5004', 'sf', '2018-05-25 17:35:21', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('f0e6e45c76b04564a4eaca625339bae0', 'sf', '2018-05-25 17:40:51', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('38247da9ccb54a5781e53f74587a24e0', 'sf', '2018-05-28 20:49:52', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('ac9ef26bf8014ffba4343091d865d5d9', 'sf', '2018-05-28 21:14:38', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('f767508424fb4295b2e7160397d13a1f', 'sf', '2018-05-28 21:22:38', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('30f5127e1a7a4c0ea2d04c6e92b12795', 'sf', '2018-05-28 21:23:16', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('8f01e2a698164ca9ae611c80ebba9d5a', 'sf', '2018-05-28 21:37:15', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('436f78456a664ff08bd467e80ec3a095', 'sf', '2018-05-28 21:39:48', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('d7fbf7cb23584762b644bf36f99269fe', 'sf', '2018-05-28 22:00:02', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('657bdeb5a1024b24bd14d76bf22a1340', 'sf', '2018-05-28 22:04:09', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('df98fd42777d4497943a29a2d7c8e592', 'sf', '2018-05-28 23:41:16', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('74e9fea7f27c4f6f8fb27b7651fa310f', 'sf', '2018-05-28 23:41:28', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('5367781a5ddb4ce88bfb18c75962c224', 'sf', '2018-05-28 23:45:13', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('f62233a3c37e4ff3a1586917f053de6f', 'sf', '2018-05-28 23:45:24', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('34b789c5ed1047049a34c355895d5e88', 'sf', '2018-05-28 23:45:47', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('fd44ac56350341d2954e62458a1fb33f', 'sf', '2018-05-28 23:46:19', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('894eb08413ce4171a32df0c319acbc24', 'sf', '2018-05-29 09:56:01', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('b453b400fbe94db0ad312dfa3c14b03b', 'sf', '2018-05-29 09:56:38', '更新', '更新用户头像', null);
INSERT INTO `log` VALUES ('a6eff16e60764fec8c6f0ce9787eda26', 'sf', '2018-05-29 09:57:08', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('ad22990d04bc4d05a355867ed4b83683', 'sf', '2018-05-29 09:57:41', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('73e0affebd074fb2ad4952bcb970467f', 'sf', '2018-05-29 10:21:28', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('1749b50e60eb454384cfa03e3edce59d', '盛飞1', '2018-05-29 12:09:19', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('50fa4f83ef9e47c88d792fc7311dad8a', 'ZZ', '2018-05-29 19:03:00', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('b86f4c5e4c6b42808ea763f02b84ac90', 'nn', '2018-05-29 19:05:00', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('549f19b6d40c4e2bbf9a296f1389c74b', '11', '2018-05-29 19:07:41', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('0375d0aa9d5148b6b4ee86786812253b', 'zzz', '2018-05-29 19:39:43', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('ee7fa5dd6b8346aeaa711b006bf0659a', 'sf', '2018-05-29 19:41:49', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('61b335d8779f43f7b33915016ca2c0af', 'zzzx', '2018-05-29 19:42:07', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('ac46aff4452a4797bf085297aedded5e', 'zzzx', '2018-05-29 19:46:11', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('4fdd5350ea6c4609a9f7a579fb8d2806', 'zzzx', '2018-05-29 19:47:37', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('200dcd26236149b9808677fee787d901', 'zzzx', '2018-05-29 19:49:08', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('d9eea604605e4f99bf6cc08b1da192bc', 'zzzx', '2018-05-29 19:50:11', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('fe7f7ba25a1f4f49b659f2aac53b1b2e', 'zzzx', '2018-05-29 19:52:17', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('b82f11c9dbd045e68c43aec31e4bd5b1', 'zzzx', '2018-05-29 19:52:17', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('2c76a82c1d974b498ff76403d68237b3', 'zzzx', '2018-05-29 19:54:57', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('c14a0f3dc4bb49da9e8fff9bd80a1da5', 'zzzx', '2018-05-29 19:56:12', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('4630e75af4cc4bc7bba9380422e423e9', 'zzzx', '2018-05-29 19:58:54', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('2b9bd11a38d543e49b9debdfaaf06a33', 'zzzx', '2018-05-29 20:15:40', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('0609d583db8f49bdaea19e0f306ac34a', 'admin', '2018-07-31 16:02:53', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('be3e51366bfc430287df067f7ec05dbc', 'admin', '2018-07-31 16:05:16', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('90f016dd0be244a89b0402cd95c4e0c5', 'admin', '2018-07-31 16:06:51', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('9dc40369c0c9485d842c8c4040ddee75', 'admin', '2018-07-31 16:14:35', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('e388c521ca8d4f2285b86a1bf2579e87', 'admin', '2018-07-31 16:23:15', '登陆', '用户登陆', null);
INSERT INTO `log` VALUES ('4c027e086db2415499fba69104d3151e', 'admin', '2018-08-03 13:06:40', '登陆', '用户登陆', null);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `userid` varchar(255) DEFAULT NULL COMMENT '用户名',
  `password` varchar(255) DEFAULT NULL COMMENT '密码',
  `nickname` varchar(255) DEFAULT NULL COMMENT '昵称',
  `sex` int(1) DEFAULT NULL,
  `age` int(5) DEFAULT NULL COMMENT '年龄',
  `profilehead` varchar(255) DEFAULT NULL COMMENT '头像',
  `profile` varchar(255) DEFAULT NULL COMMENT '简介',
  `firsttime` varchar(255) DEFAULT NULL COMMENT '注册时间',
  `lasttime` varchar(255) DEFAULT NULL COMMENT '最后登录时间',
  `status` int(1) DEFAULT NULL COMMENT '账号状态(1正常 0禁用)',
  UNIQUE KEY `userid` (`userid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('Amayadream', '123456', 'Amayadream', '1', '23', '', 'are you ok?', '2017-01-11 19:22:21', '2018-05-20 10:30:02', '1');
INSERT INTO `user` VALUES ('admin', '123', '管理员', '0', '23', 'upload/sf/sf.jpg', 'i\'m admin', '2017-01-11 19:22:21', '2018-08-03 13:06:40', '1');
INSERT INTO `user` VALUES ('sf', '123456', '盛飞', '1', '20', 'upload/sf/sf.jpg', 'd', '2017-01-11 19:22:21', '2018-05-29 19:41:49', '1');
INSERT INTO `user` VALUES ('zzzx', 'zzzx', null, null, null, null, null, null, '2018-05-29 20:15:40', '1');

package com.wms.service;

public interface TestService {
	public String getInfo();
}

package com.wms.model;

public class InOutRecordsModel {
	private String id="";
	private String goods_code="";
	private String goods_num="";
	private String supply_code="";
	private String user_code="";
	private String time="";
	private String sum_money="";
	private String single_money="";
	private String state="";
	private String startTime="";
	
	private String endTime="";
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getGoods_code() {
		return goods_code;
	}
	public void setGoods_code(String goods_code) {
		this.goods_code = goods_code;
	}
	public String getGoods_num() {
		return goods_num;
	}
	public void setGoods_num(String goods_num) {
		this.goods_num = goods_num;
	}
	public String getSupply_code() {
		return supply_code;
	}
	public void setSupply_code(String supply_code) {
		this.supply_code = supply_code;
	}
	public String getUser_code() {
		return user_code;
	}
	public void setUser_code(String user_code) {
		this.user_code = user_code;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getSum_money() {
		return sum_money;
	}
	public void setSum_money(String sum_money) {
		this.sum_money = sum_money;
	}
	public String getSingle_money() {
		return single_money;
	}
	public void setSingle_money(String single_money) {
		this.single_money = single_money;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

}

package com.wms.mapper.systemsetting;

import org.apache.ibatis.annotations.Param;

public interface PwdModifiedMapper {
	public boolean pwdModified(@Param("usercode")String usercode,@Param("password")String password);
}

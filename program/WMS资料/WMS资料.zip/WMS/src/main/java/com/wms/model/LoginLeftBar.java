package com.wms.model;

/**
 * 用于构建左侧菜单
 * @author sf
 *
 */
public class LoginLeftBar {
	
	private String id;
	private String privilegename;
	private String treelevel;
	private String url;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPrivilegename() {
		return privilegename;
	}
	public void setPrivilegename(String privilegename) {
		this.privilegename = privilegename;
	}
	public String getTreelevel() {
		return treelevel;
	}
	public void setTreelevel(String treelevel) {
		this.treelevel = treelevel;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	


	


}

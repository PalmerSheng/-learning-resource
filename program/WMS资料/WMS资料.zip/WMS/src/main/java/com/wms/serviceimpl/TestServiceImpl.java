package com.wms.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wms.mapper.TestMapper;
import com.wms.service.TestService;

@Service
public class TestServiceImpl implements TestService {

	@Autowired
	private TestMapper testMapper;
	
	public String getInfo() {
		// TODO Auto-generated method stub
		
		return testMapper.getInfo();
	}

	
}

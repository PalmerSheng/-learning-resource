package com.wms.service.assist;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wms.common.BackMessage;

public interface SupplyInfoService {

	BackMessage UpdateSupplyInfo(HttpServletRequest req, HttpServletResponse res);
	BackMessage InsertSupplyInfo(HttpServletRequest req, HttpServletResponse res);
	BackMessage DeleteSupplyInfo(HttpServletRequest req, HttpServletResponse res);
	//查询信息表
	BackMessage Info(HttpServletRequest req, HttpServletResponse res);

}

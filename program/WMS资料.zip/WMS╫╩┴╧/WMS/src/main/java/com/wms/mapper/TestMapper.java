package com.wms.mapper;

public interface TestMapper {
	public String getInfo();
}

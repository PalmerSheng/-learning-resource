package com.wms.model;

public class Privilegeinfo {

}

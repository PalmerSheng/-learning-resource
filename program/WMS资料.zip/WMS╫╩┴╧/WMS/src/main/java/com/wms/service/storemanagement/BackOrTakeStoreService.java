package com.wms.service.storemanagement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wms.common.BackMessage;

public interface BackOrTakeStoreService {

	public BackMessage backStore(HttpServletRequest req, HttpServletResponse res);
	public BackMessage backStore01(HttpServletRequest req, HttpServletResponse res);

	public BackMessage takeStore(HttpServletRequest req, HttpServletResponse res);
	public BackMessage takeStore01(HttpServletRequest req, HttpServletResponse res);

	
}

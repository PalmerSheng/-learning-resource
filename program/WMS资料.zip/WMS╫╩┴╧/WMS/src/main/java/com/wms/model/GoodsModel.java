package com.wms.model;

public class GoodsModel {
	private String id="";
	private String goods_code="";
	private String goods_name="";
	private String goods_num="";
	private String time="";
	private String single_money="";
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getGoods_code() {
		return goods_code;
	}
	public void setGoods_code(String goods_code) {
		this.goods_code = goods_code;
	}
	public String getGoods_name() {
		return goods_name;
	}
	public void setGoods_name(String goods_name) {
		this.goods_name = goods_name;
	}
	public String getGoods_num() {
		return goods_num;
	}
	public void setGoods_num(String goods_num) {
		this.goods_num = goods_num;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getSingle_money() {
		return single_money;
	}
	public void setSingle_money(String single_money) {
		this.single_money = single_money;
	}
	

}

package com.wms.service.storemanagement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wms.common.BackMessage;

public interface DataBaseService {

	public BackMessage dataBaseList(HttpServletRequest req, HttpServletResponse res);

}

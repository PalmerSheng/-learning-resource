package com.wms.service.assist;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wms.common.BackMessage;

public interface StoreKeeperService {
	//修改信息
	BackMessage UpdateStoreKeeperInfo(HttpServletRequest req, HttpServletResponse res);
	//插入信息
	BackMessage InsertStoreKeeperInfo(HttpServletRequest req, HttpServletResponse res);
	
	//删除信息
	BackMessage DeleteStoreKeeperInfo(HttpServletRequest req, HttpServletResponse res);

	//查询信息表
	BackMessage StoreKeeperInfo(HttpServletRequest req, HttpServletResponse res);
	
}

package com.wms.service.storemanagement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wms.common.BackMessage;

public interface SumStoreService {

	public BackMessage sumStore(HttpServletRequest req, HttpServletResponse res);

}

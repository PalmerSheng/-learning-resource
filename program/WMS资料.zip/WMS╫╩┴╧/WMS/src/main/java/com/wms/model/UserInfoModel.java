package com.wms.model;

public class UserInfoModel {
		private String id="";
		private String level="";
		private String username="";
		private String usercode="";
		private String password="";
		private String unit_code="";//工作单位号
		private String depart="";
		private String group1="";
		private String code="";//工作单位号
		private String tel="";
		private String user_state="";
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getUsercode() {
			return usercode;
		}
		public void setUsercode(String usercode) {
			this.usercode = usercode;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getUnit_code() {
			return unit_code;
		}
		public void setUnit_code(String unit_code) {
			this.unit_code = unit_code;
		}
		public String getDepart() {
			return depart;
		}
		public void setDepart(String depart) {
			this.depart = depart;
		}
		
		public String getGroup1() {
			return group1;
		}
		public void setGroup1(String group1) {
			this.group1 = group1;
		}
		public String getCode() {
			return code;
		}
		public void setCode(String code) {
			this.code = code;
		}
		public String getTel() {
			return tel;
		}
		public void setTel(String tel) {
			this.tel = tel;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getLevel() {
			return level;
		}
		public void setLevel(String level) {
			this.level = level;
		}
		public String getUser_state() {
			return user_state;
		}
		public void setUser_state(String user_state) {
			this.user_state = user_state;
		}
		

}



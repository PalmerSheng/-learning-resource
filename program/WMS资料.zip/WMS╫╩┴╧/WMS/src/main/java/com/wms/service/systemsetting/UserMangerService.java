package com.wms.service.systemsetting;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wms.common.BackMessage;
import com.wms.model.MessageDefined;

public interface UserMangerService {
	
	public BackMessage selUser(HttpServletRequest req, HttpServletResponse res);
	public BackMessage delUser(HttpServletRequest req, HttpServletResponse res);
	public BackMessage updateUserInfo(HttpServletRequest req,HttpServletResponse res,MessageDefined defined);


}

package com.wms.mapper.query;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wms.model.InOutRecordsModel;

public interface InOutRecordsMapper {
	//加载信息表
			public List<InOutRecordsModel> GetInOutRecords(
					@Param("startTime")String startTime,
					@Param("endTime")String endTime);

}
